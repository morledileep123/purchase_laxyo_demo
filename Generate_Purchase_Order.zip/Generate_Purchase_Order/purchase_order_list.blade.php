@extends('../layouts.master')
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" rel="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.colVis.min.js"></script>
@section('content')

<div class="container">
  @if (Session::has('success'))
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert">
            <i class="fa fa-times"></i>
        </button>
        <strong>Success !</strong> {{ session('success') }}
    </div>
  @endif
</div>

<div class="container-fluid">
  <div class="card">
  <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <h4>Purchase Order Lists</h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <div class="card-header" style="padding:4px; border:none;">
                <a href="{{ url('generate_po/create') }}" class="btn btn-success">Create PO </a>
                <a href="{{ url()->previous() }}" class="btn btn-secondary">Back</a>
              </div>
              
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            

            <div class="card">
             
              <!-- /.card-header -->
              <div class="card-body">

                <div class="table-responsive">
                  <table class="table table-bordered table-hover" id="inv-table">
                  <thead>
                  <tr>
                    <th>S No</th>
                    <th>Code</th>
                    <th>Company Name</th>
                    <th>Items Names</th>
                    <th>Created date</th>
                    <th>Action</th>
                    
                  </tr>
                  </thead>
                  <tbody>
                    @php $i=1; @endphp
                  @foreach($data as $row)
                     <tr>
                      <td>{{ $i++ }}</td>
                      <td>{{ $row->code }}</td>

                      @if($row->vendor_details_company != '')
                          <td>{{ $row->vendor_details_company }}</td> 
                      @else
                          <td>{{ $row->vender_detail }}</td>
                      @endif
                                  
                      <td>{{ $row->invoice_product }}</td>
                      <td>{{ $row->date }}</td>
                      
                      <td>
                        <a href="{{url('pdf_download',$row->id )}}" class="btn btn-primary btn-sm"><i class="fas fa-download"></i></a>
                      </td>
                     
                    </tr>
                  @endforeach
                  
                  
                  </tbody>
                  
                </table>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
</div>

<script>
      $(document).ready(function() {
    $('#inv-table').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'columnsToggle'
        ]
    } );
} );
    </script>

@endsection