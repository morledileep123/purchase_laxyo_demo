<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\Invoice;
use App\Invoice_details;
use App\unitofmeasurement;
use App\Vendor;
use App\SiteName;
use App\User;
use App\prch_quotationwise_requs;
use App\Company_site_name;
use DB;
use Carbon\Carbon;
use PDF;
Use Mail;
use Storage;
use Auth;

class GoodsReceivedNoteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $user_id = Auth::user()->id;
      $invoices = Invoice::where(['user_id'=>$user_id,'user_send_grr'=>'0'])->get();
      $invoices_send = Invoice::where(['user_id'=>$user_id,'user_send_grr'=>'1'])->get();
      return view('Invoices.index',compact('invoices','invoices_send'));  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    { 
      $units = unitofmeasurement::get();
      $vendors = Vendor::all();
      $sites = SiteName::all();
      $items = prch_quotationwise_requs::where('manager_status','=',1)->where('item_status','=',0)->pluck('item_name');
      return view('Invoices.create',compact('vendors','units','sites','items'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // return $request;
        $string = str_shuffle('12ABCDJIKJGTIRO41581425123GJAIKOUJWUHENBJFJSUHAFRJE3456FASDFSD56456FA4SD5F4S57890');
        $grn_no = '#GRR-'.substr($string, 0,7);

        $company = Company_site_name::where('id',$request->company_location)->first();

        if('abc' != $request->vender_details){
            $vender_details = Vendor::where('id',$request->vender_details)->first();  
            $data = new Invoice;

            $data->grn_no = $grn_no;
            $data->invoice_no = $request->invoice_no;
            $data->invoice_date = $request->invoice_date;
            $data->delivery_address = $request->delivery_address;
            $data->company_location = $company->full_address;
            $data->counter = $request->counter;
            $data->comments = $request->comments;
            $data->delivery_date = $request->delivery_date;
            $data->total = $request->total;
            $data->grand_total = $request->grand_total;
            $data->amount_rupees = $request->amount_rupees;
            $data->user_id = $request->user_id;
            $data->vender_company = $vender_details->company;
            $data->vender_email = $vender_details->company_email;
            $data->vender_address1 = $vender_details->address1;
            $data->vender_address2 = $vender_details->address2;
            $data->vender_state = $vender_details->state;
            $data->vender_city = $vender_details->city;
            $data->vender_person_name = $vender_details->person_name;
            $data->vender_person_email = $vender_details->person_email;
            $data->vender_person_no = $vender_details->company_mobile;
            $data->save();
        }
        else{
            $data = new Invoice;

            $data->grn_no = $grn_no;
            $data->invoice_no = $request->invoice_no;
            $data->invoice_date = $invoice_date;
            $data->delivery_address = $request->delivery_address;
            $data->company_location = $company->full_address;
            $data->counter = $request->counter;
            $data->comments = $request->comments;
            $data->delivery_date = $request->delivery_date;
            $data->total = $request->total;
            $data->grand_total = $request->grand_total;
            $data->amount_rupees = $request->amount_rupees;
            $data->user_id = $request->user_id;
            $data->vender_detail = $request->vender_detail;

            $data->save();  
        }
    
        $item_id = $data->id;

        $count = count($request->invoice_product);

        $i = 0;
        while($i < $count){

        $string = str_shuffle('12ABCDJIKJGTIRO41581425123GJAIKOUJWUHENBJFJSUHAFRJE3456FASDFSD56456FA4SD5F4S57890');
        $invoice_no_code = substr($string, 0,7);

          if($request->invoice_product[$i] !=''){
            $newdata = array(
                'item_id' => $item_id,
                'invoice_no_code' => $invoice_no_code,                      
                'invoice_product' => $request->invoice_product[$i],
                'quantity_unit' => $request->quantity_unit[$i],
                'description' => $request->description[$i],
                'product_qty' => $request->product_qty[$i],
                'product_price' => $request->product_price[$i],
                'product_tax' => $request->product_tax[$i],
                'product_discount' => $request->product_discount[$i],
                'taxa' => $request->taxa[$i],
                'disca' => $request->disca[$i],
                'product_subtotal' => $request->product_subtotal[$i],
                
            );
            
          Invoice_details::create($newdata);

          }       
          $i++;
        }

      return redirect('GoodsReceivedNote')->with('success','Invoice generate successfully.');
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Invoice  $invoice
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Invoice::where('id',$id)->first(); 
        $items = Invoice_details::where('item_id',$id)->get(); 

        return view('Invoices.view_invoice',compact('data','items'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Invoice  $invoice
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // return $id;
        $data = Invoice::where('id',$id)->first(); 
        $items = Invoice_details::where('item_id',$id)->get(); 
        return view('Invoices.edit',compact('data','items'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Invoice  $invoice
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        // return $request;
        $data = Invoice::find($id); 
        $data->invoice_no =  $request->get('invoice_no'); 
        $data->grn_no =  $request->get('grn_no'); 
        $data->invoice_date =  $request->get('invoice_date');  
        $data->delivery_date =  $request->get('delivery_date');  
        $data->vender_detail =  $request->get('vender_detail');  
        $data->vender_company =  $request->get('vender_company');  
        $data->vender_email =  $request->get('vender_email');  
        $data->vender_address1 =  $request->get('vender_address1');  
        $data->vender_address2 =  $request->get('vender_address2');  
        $data->vender_state =  $request->get('vender_state');  
        $data->vender_city =  $request->get('vender_city');  
        $data->vender_person_name =  $request->get('vender_person_name');  
        $data->vender_person_email =  $request->get('vender_person_email');  
        $data->vender_person_no =  $request->get('vender_person_no');  
        $data->delivery_address =  $request->get('delivery_address');  
        $data->company_location =  $request->get('company_location'); 
        $data->comments =  $request->get('comments'); 
        $data->grand_total =  $request->get('grand_total');  
        $data->amount_rupees =  $request->get('amount_rupees');  
           
        $count = count($request->invoice_product);
        for($x = 0; $x < $count; $x++) {
            $input = [
              'invoice_product' => $request->invoice_product[$x],
              'description' => $request->description[$x],
              'quantity_unit' => $request->quantity_unit[$x],
              'product_qty' => $request->product_qty[$x],
              'product_price' => $request->product_price[$x],              
              'product_tax' => $request->product_tax[$x],
              'product_discount' => $request->product_discount[$x],
              'product_subtotal' => $request->product_subtotal[$x],              
            ];
        Invoice_details::where(['item_id'=>$id,'invoice_no_code' => $request->invoice_no_code[$x]])->update($input);
         
        }
      
        $data->save();  
        return redirect('GoodsReceivedNote')->with('success','GRR updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Invoice  $invoice
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
      $data=Invoice::find($request->invoice_id);
      $data->delete();
      return back()->with('delete', 'GRN deleted Successfully');
    }

    public function invoicedownloaduser($id)
    {
      $data = Invoice::where('id',$id)->first(); 
      $items = Invoice_details::where('item_id',$id)->get();       
        
      // return view('Invoices.download_invoice_receipt',compact('data','items'));
      $pdf = PDF::loadView('Invoices.download_invoice_receipt',compact('data','items'));

      return $pdf->download('GRR.pdf');
    }

    public function send_vendor_invoice(Request $request)
    {
        $svendor = $request->post('query');
        $svendors = Vendor::where('id',$svendor)->get();

        $output = '';
        foreach($svendors as $row)
{
$output .= 'Company Name : '.$row->company .' 
Company email : '.$row->company_email.'
Address 1 : '.$row->address1.'
Address 2 : '.$row->address2.'
City : '.$row->city.'
State : '.$row->state.'
Person name : '.$row->person_name   .'
Person Email : '.$row->person_email.'
Person Mobile : '.$row->company_mobile.'
';

}
        $output .= '';

        echo $output;
    }


    public function company_details(Request $request)
    {
      $query = $request->get('company');
      $data = Company_site_name::where('id',$query)->pluck('full_address');
      return response()->json($data);
    }

    public function sendmanager($id)
    {
      // return $id;
      $user_id = Auth::user();
      $sender = $user_id->email;

      if($user_id->id == '223') {
        $resever_data = User::find(29);
        $reseve = 'sourabh.joshi.sdbg@gmail.com';

        $data = [];
        Mail::send('Invoices.send_mail_to_manager', $data, function($message) use($reseve,$sender)
        {
            $message->to($reseve)->subject('Your Side user send GRR !');
            $message->from($sender);
            
        });
      }
      elseif(condition){
        return "else if condition";
      }
      else{
        return "else condition";
      }

      $manager_id = $resever_data->id;
      $datas = Invoice::where('id',$id)->update(['user_send_grr'=>1,'manager_status'=>1,'manager_id'=>$manager_id]);
      return redirect('GoodsReceivedNote')->with('success' , 'GRR Send to manager.'); 

    }


    // Manager Section start

    public function manager_grr_index()
    {
      $user_id = Auth::user()->id;
      $invoices = Invoice::where(['manager_id'=>$user_id,'manager_status'=>'1','manager_aprove'=>0])->get();
      $invoices_send = Invoice::where(['manager_id'=>$user_id,'manager_status'=>'1','manager_aprove'=>1])->get();

      return view('Invoices.manager_index',compact('invoices','invoices_send'));
    }

    public function manager_grr_view($id)
    {
      $data = Invoice::where('id',$id)->first(); 
      $items = Invoice_details::where('item_id',$id)->get(); 

      return view('Invoices.view_manager',compact('data','items'));
    }

    public function invoicedownloadmanager($id)
    {
      $data = Invoice::where('id',$id)->first(); 
      $items = Invoice_details::where('item_id',$id)->get();       
        
      // return view('Invoices.download_invoice_receipt',compact('data','items'));
      $pdf = PDF::loadView('Invoices.download_invoice_receipt',compact('data','items'));

      return $pdf->download('GRR.pdf');
    }

    public function reject_invoice(Request $request,$id)
    {
      $data = Invoice::find($id); 

      $data->reject = $request->reject;

      $data->save();
      return back(); 

    }

    public function sendadmin($id)
    {
      $user_id = Auth::user();
      $sender = $user_id->email;

      $resever_data = User::find(209);
      $reseve = 'sourabh.joshi.sdbg@gmail.com';

      $data = [];
      Mail::send('Invoices.send_mail_to_admin', $data, function($message) use($reseve,$sender)
      {
        $message->to($reseve)->subject('Your Side user send GRR !');
        $message->from($sender);  
      });

      Mail::send('Invoices.send_mail_to_accountant', $data, function($message) use($reseve,$sender)
      {
        $message->to('sourabh.joshi.sdbg@gmail.com')->subject('Your Side user send GRR !');
        $message->from($sender); 
      });
      // hr@laxyo.com Devendra sir email id

      $manager_id = $resever_data->id;
      $datas = Invoice::where('id',$id)->update(['manager_aprove'=>1,'admin_status'=>1,'acountent_status'=>1]);
      return redirect('manager_grr_index')->with('success' , 'Send to Admin and Accountant .'); 
    }



//  Admin Section start

    public function admin_grr_index()
    {
      $invoices = Invoice::where(['admin_status'=>'1','admin_approve'=>0])->get();
      $invoices_send = Invoice::where(['admin_status'=>'1','admin_approve'=>1])->get();

      return view('Invoices.admin_index',compact('invoices','invoices_send'));
    }

    public function admin_grr_view($id)
    {
      $data = Invoice::where('id',$id)->first(); 
      $items = Invoice_details::where('item_id',$id)->get(); 

      return view('Invoices.view_admin',compact('data','items'));
    }

    public function invoicedownloadadmin($id)
    {
      $data = Invoice::where('id',$id)->first(); 
      $items = Invoice_details::where('item_id',$id)->get();       
        
      // return view('Invoices.download_invoice_receipt',compact('data','items'));
      $pdf = PDF::loadView('Invoices.download_invoice_receipt',compact('data','items'));

      return $pdf->download('GRR.pdf');
    }

    public function sendsuperadmin($id)
    {
      $user_id = Auth::user();
      $sender = $user_id->email;

      $resever_data = User::find(2);
      // $reseve = 'sourabh.joshi.sdbg@gmail.com';

      // $data = [];
      // Mail::send('Invoices.send_mail_to_superadmin', $data, function($message) use($reseve,$sender)
      // {
      //   $message->to($reseve)->subject('Your Side user send GRR !');
      //   $message->from($sender);
          
      // });

      $manager_id = $resever_data->id;
      $datas = Invoice::where('id',$id)->update(['admin_approve'=>1,'acountent_status'=>1  ]);
      return redirect('admin_grr_index')->with('success','Send to Accountant.'); 
    }

// Accountant Section start

    public function accountant_grr_index()
    {
      $invoices = Invoice::where(['acountent_status'=>'1','acountent_approve'=>0])->get();
      $invoices_send = Invoice::where(['acountent_status'=>'1','acountent_approve'=>1])->get();

      return view('Invoices.accountant_index',compact('invoices','invoices_send'));
    }

    public function accountant_grr_view($id)
    {
      $data = Invoice::where('id',$id)->first(); 
      $items = Invoice_details::where('item_id',$id)->get(); 

      return view('Invoices.view_accountant',compact('data','items'));
    }

    public function invoicedownloadaccountant($id)
    {
      $data = Invoice::where('id',$id)->first(); 
      $items = Invoice_details::where('item_id',$id)->get();       
        
      // return view('Invoices.download_invoice_receipt',compact('data','items'));
      $pdf = PDF::loadView('Invoices.download_invoice_receipt',compact('data','items'));

      return $pdf->download('GRR.pdf');
    }

    public function sendapprove($id)
    {
      $datas = Invoice::where('id',$id)->update(['acountent_approve'=>1,'approve'=>1 ]);
      return redirect('accountant_grr_index')->with('success' , 'Successfully.'); 
    }



    // Super Admin Section start

    // public function superadmin_grr_index()
    // {
    //   $invoices = Invoice::where(['superadmin_status'=>'1','superadmin_approve'=>0])->get();
    //   $invoices_send = Invoice::where(['superadmin_status'=>'1','superadmin_approve'=>1])->get();

    //   return view('Invoices.superadmin_index',compact('invoices','invoices_send'));
    // }

    // public function superadmin_grr_view($id)
    // {
    //   $data = Invoice::where('id',$id)->first(); 
    //   $items = Invoice_details::where('item_id',$id)->get(); 

    //   return view('Invoices.view_superadmin',compact('data','items'));
    // }

    // public function invoicedownloadsuperadmin($id)
    // {
    //   $data = Invoice::where('id',$id)->first(); 
    //   $items = Invoice_details::where('item_id',$id)->get();       
        
    //   // return view('Invoices.download_invoice_receipt',compact('data','items'));
    //   $pdf = PDF::loadView('Invoices.download_invoice_receipt',compact('data','items'));

    //   return $pdf->download('GRR.pdf');
    // }

    // public function sendaccount($id)
    // {
    //   $user_id = Auth::user();
    //   $sender = $user_id->email;

    //   $resever_data = User::find(21);
    //   $reseve = 'sourabh.joshi.sdbg@gmail.com';

    //   $data = [];
    //   Mail::send('Invoices.send_mail_to_accountant', $data, function($message) use($reseve,$sender)
    //   {
    //     $message->to($reseve)->subject('Your Side user send GRR !');
    //     $message->from($sender);
          
    //   });

    //   $manager_id = $resever_data->id;
    //   $datas = Invoice::where('id',$id)->update(['superadmin_approve'=>1,'acountent_status'=>1  ]);
    //   return redirect('superadmin_grr_index')->with('success' , 'Send to Accountant.'); 
    // }




    
    


}
