<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Department;
use App\Brand;
use App\item;
use App\Vendor;
use App\SiteName;
use App\unitofmeasurement;
use App\item_category;
use App\Sub_categories;
use App\Users;
use App\location;
use Helper;
use PDF;
use PDFs;
use DB;
use Excel;
use Illuminate\Http\Request;
use App\Imports\ItemsImport;
use App\Exports\ItemsExcelExport;
use App\Exports\ItemsExport;
use App\itemconsumable;
use File;
use Response;
use Validator;
use Session;


class ItemController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {      
        $category = item_category::get();
        $department = Department::get();
        $sites = SiteName::get(); 
        $vendor = Vendor::get();
        $units = unitofmeasurement::get();
        $items = item::all();
        $stock = DB::table("prch_items")->get()->sum("current_stock"); 
        return view('item.index', compact('category','department','items','sites','stock'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $units = unitofmeasurement::get();
        $category = item_category::get();
        $department = Department::get();
        $brand = Brand::get();
        $vendor = Vendor::all();
        $sites = SiteName::all(); 

        return view('item.create',compact('units','category','department','brand','sites','vendor'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
            'item_name' => 'required',
            'description' => 'required',
            'unit_id' => 'required',
            'buy_sale_both' => 'required',
            'category_id' => 'required',
            'department' => 'required',
            'location' => 'required',  
        ]);
       
        $ids = DB::select(DB::raw("SELECT nextval('prch_items_id_seq')"));
        $l_id = $ids[0]->nextval+1;


        $categories = item_category::where('id', $request->category_id)->first();
        $cat_id = $request->category_id;
        $cat_skey = $categories->short_key;

        $string = str_shuffle('12ABCDJIKJGTIRO41581425123GJAIKOUJWUHENBJFJSUHAFRJE3456FASDFSD56456FA4SD5F4S57890');

        $order_id = $cat_skey.$cat_id.substr($string, 0,5);

        $datas['category_id'] = $categories->name;

        $datas = new item;
                $datas['item_number'] = $order_id;
                $datas->part_number = $request->input('part_number');
                $datas->item_name = $request->input('item_name');
                $datas->description = $request->input('description');
                $datas->unit_id = $request->input('unit_id');
                $datas->rate = $request->input('rate');
                $datas->hsn_code = $request->input('hsn_code');
                $datas->gst = $request->input('gst');
                $datas->buy_sale_both = $request->input('buy_sale_both');
                $datas->category_id = $request->input('category_id');
                $datas->brand_id = $request->input('brand_id');
                $datas->vendor_name = $request->input('vendor_name');
                $datas->vendor_location = $request->input('vendor_location');
                $datas->product_service_name = $request->input('product_service_name');
                $datas->current_stock = $request->input('current_stock');
                $datas->min_stock_level = $request->input('min_stock_level');
                $datas->max_stock_level = $request->input('max_stock_level');
                $datas->department = $request->input('department');
                $datas->location = $request->input('location');
                $datas->consumption = $request->input('consumption');
                $datas->consumable = $request->input('consumable');
                $datas->save();
         
        return redirect()->route('item.index')->with('success','Item Added successfully.');
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\item  $item
     * @return \Illuminate\Http\Response
     */
    public function show(item $item)
    { 
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\item  $item
     * @return \Illuminate\Http\Response
     */
    // public function edit(item $item)
    // {
    //     $units = unitofmeasurement::get();
    //     $category = item_category::get();
    //     $location = location::get();
    //     $brand = Brand::get();
    //     $department = Department::get();
    //     $itemconsumable = itemconsumable::get();
    //     return view('item.edit',compact('item','units','category','location','brand','department','itemconsumable'));
    // }
    public function edit($id)
    {
        $item = item::find($id);
        $category = item_category::get();
        $department = Department::get();
        $units = unitofmeasurement::get();
        return view('item.edit',compact('item','category','department','units'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\item  $item
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request,$id)
    {

        $item = item::find($id); 
        // $categories = item_category::where('id', $request->category_id)->pluck('name');
        $units = unitofmeasurement::where('id', $request->unit_id)->pluck('name')->first();
        $item->part_number =  $request->get('part_number');  
        $item->item_name = $request->get('item_name');  
        // $item->category_id = $categories;
        $item->unit_id = $units; 
        $item->hsn_code = $request->get('hsn_code'); 
        $item->rate = $request->get('rate'); 
        $item->gst = $request->get('gst');
        $item->save();   
        return redirect()->route('item.index')->with('success','items details updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\item  $item
     * @return \Illuminate\Http\Response
     */

    public function destroy($id)
    {
        $items=item::find($id)->delete();
        return redirect()->route('item.index')->with('success','Item deleted successfully');
    }
   
    public function itemcat(Request $request){
    $category_id = $request->id;
    $cat_name = item_category::where('id',$category_id)->pluck('name');
    $items = item::where('category_id',$cat_name)->get();
    return view('item.cat_filter',compact('items','cat_name','category_id'));
        }

    public function itemsite(Request $request){
    $ste_name = $request->name;
    $site_name = SiteName::where('name',$ste_name)->pluck('name');
    $items = item::where('location',$site_name)->get();
    return view('item.site_filter',compact('items','site_name','ste_name'));
        }

    // public function itemsfilter(Request $request){
           
    //        $items = item::where('category_id',$request->cat)->where('department',$request->dep)->get();
    //       return view('item.table',compact('items'));
    // }

    public function export_pdf()
      {
         $category = item_category::get();
         $department = Department::get(); 
         $items = item::all();
        return view('item.multiple_item_create',compact('category','department','items'));
      }

  
    public function excelItemsnew(){
            // return "reey";
            // $datas = Excel::toCollection(new ItemsImport,request()->file('excel_data'));
            $datas = Excel::toCollection(new ItemsImport,request()->file('excel_data'));
            //dd($datas);

             
             $errors= array();
             $error_name = '';
             $workid = '';
        foreach($datas as $sales){
          foreach($sales as $items){
                //dd($items['subcategory_name']);
                    $status = true;
                    if($status){
                        if($items['category_name'] != ''){
                          $category_id = item_category::where('id', $items['category_name'])->first();
                          if($category_id){
                             $catid = $category_id->id;
                             $status = true;

                          }else{

                              $error_name = "Category is not found in database";
                              $status = 0;
                              $catid = '';
                          }
                    }else{

                              $error_name = "Category is Empty";
                              $status = 0;
                              $catid = '';
                    }
                    
                 }

                  if($status){
                        if($items['subcategory_name'] != ''){
                          $subcategory_id = Brand::where('id', $items['subcategory_name'])->where('category_id', $catid)->first();
                          if($subcategory_id){
                             $subcatid = $subcategory_id->id;
                             $status = true;

                          }else{

                              $error_name = "Sub-Category is not found in database or category is wrong";
                              $status = 0;
                              $subcatid = '';
                          }
                    }else{

                              $error_name = "Sub-Category is Empty";
                              $status = 0;
                              $subcatid = '';
                    }
                    
                 }


                 if($status){
                        if($items['department'] != ''){
                          $department = Department::where('id', $items['department'])->first();
                          if($department){
                             $dept = $department->id;
                             $status = true;

                          }else{

                              $error_name = "Department is not found in database";
                              $status = 0;
                              $dept = '';
                          }
                    }else{
                              $error_name = "Department is Empty";
                              $status = 0;
                              $dept = '';

                    }
                    
                 }


                  if($status){
                        if($items['units'] != ''){
                          $unit = unitofmeasurement::where('id', $items['units'])->first();
                          if($unit){
                             $unitid = $unit->id;
                             $status = true;

                          }else{

                              $error_name = "Unit of measurement is not found in database";
                              $status = 0;
                              $unitid = '';
                          }
                    }else{

                              $error_name = "Unit of measurement is Empty";
                              $status = 0;
                              $unitid = '';
                    }
                    
                 }

                 if($status){
                        if($items['consumeable'] != ''){
                          $consume = itemconsumable::where('id', $items['consumeable'])->first();
                          if($consume){
                             $consum = $consume->id;
                             $status = true;

                          }else{

                              $error_name = "consumeable type is not found in database";
                              $status = 0;
                              $consum = '';
                          }
                    }else{

                              $error_name = "consumeable Field is Empty";
                              $status = 0;
                              $consum = '';
                    }
                    
                 }



                 if($status){
                        if($items['titles'] != ''){
                         $item_name = item::where('title',$items['titles'])->where('category_id',$catid)->where('brand',$subcatid)->where('department',$dept)->where('unit_id',$unitid)->where('cons_id',$consum)->first();
                          if($item_name){
                             $titles = $item_name->id;
                             $status = true;

                          }else{

                        
                              $barcode = itemidentity(11,13);
                         $item_number = $barcode;
                         $array = array(
                                        'item_number'  =>  $item_number,
                                        'title'  => $items['titles'],
                                        'hsn_code'  => $items['hsn_code'],
                                        'category_id'  => $catid,
                                        'brand'  => $subcatid,
                                        'department'  => $dept,
                                        'unit_id'  => $unitid,
                                        'cons_id'  => $consum,
                                        'description' => $items['description'],
                               );
                         $insrt = item::create($array);
                         $titles = $insrt->id;
                         $status = true;


                          }

                    }else{

                              $error_name = "Item is Field is Empty";
                              $status = 0;
                              $titles = '';
                    }
                    
                 }
                 
             $errors[] = array(
                            //'item_number'  =>  $item_number,
                            'title'  => $items['titles'],
                            'hsn_code'  => $items['hsn_code'],
                            'category_id'  => $items['category_name'],
                            'brand'  => $items['subcategory_name'],
                            'department'  => $items['department'],
                            'unit_id'  => $items['units'],
                            'cons_id'  =>$items['consumeable'],
                            'description' => $items['description'],
                            //'quantity' => $items['quantity'],
                            'error_filed' => $error_name,

             );
          //}

              }
      }
       if(count($errors) !=0){
            return Excel::download(new ItemsExport($errors), 'Item_error.xlsx');

        }else{
          
           return redirect()->route('item.index');
        }
  }

    public function downloadSheetFormat(){
        $path = storage_path('data.xlsx');
        return Response::download($path);
    }

    public function excelImportItems(Request $request){

        $this->validate($request, ['excel_data' => 'required']);

        $datas = Excel::import(new ItemsImport,request()->file('excel_data'));

        if($datas){
            return redirect()->route('item.index')->with('success','Item Added successfully.');
        }
    }
 
    public function excelItemsExport() 
    {
        return Excel::download(new ItemsExcelExport, 'Items_'.date("d-M-Y").'.xlsx');
    }

}
