@extends('../layouts.master')
@section('content')

<div class="container-fluid">
  <div class="card">
  <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mx-3">
          <div class="col-sm-6">
            <h4>Update <small>GRR</small></h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <div class="card-header" style="padding:4px; border:none;">
                <a href="{{ url()->previous() }}" class="btn btn-secondary btn-sm">Back</a>
              </div>              
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">  

                <div class="container-fluid"> 
                        
                    <div class="row">
                        <h4 style="text-align:center; display: block; margin: 0 auto; margin-top: 20px !important;">GRR</h4>
                    </div>
                    <br>

                    <form action="{{route('GoodsReceivedNote.update',$data->id)}}" method="Post">
                    @csrf
                    @method('PUT')
                    <div class="row">
                        <div class="col-4">
                            <input type="text" name="invoice_no" class="form-control input-sm" value="{{ $data->invoice_no }}" />
                            <input type="text" name="grn_no" class="form-control input-sm" value="{{ $data->grn_no }}" />
                            <input type="text" name="invoice_date" class="form-control input-sm" value="{{$data->invoice_date }}" />
                            <input type="text" name="delivery_date" class="form-control input-sm" value="{{$data->delivery_date}}"/>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-md-4">
                            <small>Vendor Detail</small>
                            @if(!empty($data->vender_company))        
                            <input type="text" name="vender_company" value="{{$data->vender_company}}" class="form-control">
                            <input type="text" name="vender_email" value="{{$data->vender_email}}" class="form-control">
                            <input type="text" name="vender_address1" value="{{$data->vender_address1}}" class="form-control">
                            <input type="text" name="vender_address2" value="{{$data->vender_address2}}" class="form-control">
                            <input type="text" name="vender_state" value="{{$data->vender_state}}" class="form-control">
                            <input type="text" name="vender_city" value="{{$data->vender_city}}" class="form-control">
                            <input type="text" name="vender_person_name" value="{{$data->vender_person_name}}" class="form-control">
                            <input type="text" name="vender_person_email" value="{{$data->vender_person_email}}" class="form-control">
                            <input type="text" name="vender_person_no" value="{{$data->vender_person_no}}" class="form-control">
                            @else
                            <textarea type="text" class="form-control" name="vender_detail">{{ $data->vender_detail }}</textarea>      
                            @endif

                        </div>
                        <div class="col-md-4">
                            <small>Delivery Location</small>
                            <textarea type="text" class="form-control" name="delivery_address">{{ $data->delivery_address }}</textarea>
                        </div>
                        <div class="col-md-4">
                            <small>Company Name</small>
                            <textarea type="text" class="form-control" name="company_location">{{ $data->company_location }}</textarea>

                        </div>
                    </div>
                    <br>

                    <div class="row table-responsive">
                    <table class="table" border="2">
                        <thead>
                        <tr>
                            <th width="10%">Item Name</th>
                            <th width="10%">Description</th>
                            <th width="5%">Unit</th>
                            <th width="5%">Qty</th>
                            <th width="5%">Rate</th>
                            <th width="5%">Tax(%)</th>
                            <th width="5%">Discount</th>
                            <th width="5%">Amount</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($items as $key => $row)
                            <tr>
                              <input type="hidden" name="invoice_no_code[]" value="{{$row->invoice_no_code}}">
                              <td><input type="text" name="invoice_product[]" value="{{$row->invoice_product}}" class="form-control"></td>
                              <td><textarea class="form-control" name="description[]">{{$row->description}}</textarea></td>
                              <td><input type="text" name="quantity_unit[]" value="{{$row->quantity_unit}}" class="form-control"></td>
                              <td><input type="text" name="product_qty[]" value="{{$row->product_qty}}" class="form-control" readonly></td>
                              <td><input type="text" name="product_price[]" value="{{$row->product_price}}" class="form-control" readonly></td>
                              <td><input type="text" name="product_tax[]" value="{{$row->product_tax}}" class="form-control" readonly></td>
                              <td><input type="text" name="product_discount[]" value="{{$row->product_discount}}" class="form-control" readonly></td>
                              <td><input type="text" name="product_subtotal[]" value="{{$row->product_subtotal}}" class="form-control" readonly></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>          
                    </div>
                    <br>
                     
                    <div class="col-5 float-right">
                    <p style="margin-left:20px;"><strong>Final Amount</strong>&nbsp; : &nbsp;<input type="text" name="grand_total" value="{{$data->grand_total}}" class="form-control"> </p>
                    <p style="margin-left:20px;"><strong>Final Amount In words</strong>&nbsp; : &nbsp; <input type="text" name="amount_rupees" value="{{$data->amount_rupees}}" class="form-control"></p>
                    </div>
                          
                </div>

                <div class="row">
                    <div class="col-12">
                      <strong>Comment :</strong>
                      <textarea type="text" class="form-control" style="white-space: pre-line" name="comments">{{ $data->comments }}</textarea> 
                    </div>
                </div>
                <br> 

               
                <br>
                <button type="submit" name="submit" class="btn btn-primary">Update</button>

                </form>
                <br>
            
    
                </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
    
  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
    
    $(document).ready(function(){
      $("#sign").change(function(){
       let sign = $("#sign").val();
       
       jQuery.ajax({
       url:'/company_sign_pics_update',
       type:'get',
       data:'sign='+sign+'&_token={{csrf_token()}}',
       success:function(result){
        
        $('#signature').attr('src',result); 
       }
       })
         // $("#b").val(a);
    });

    });
</script>

@endsection