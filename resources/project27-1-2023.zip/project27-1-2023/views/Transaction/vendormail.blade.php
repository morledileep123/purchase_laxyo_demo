<!DOCTYPE html>
<html>
<head>
    <title>New Request For Vendor</title>
</head>
<body>
 <div>
  <h1>Hi {{ $person_email }} ! <h1></br>
    <h2> Side </h2><h3> Laxyo PVT LTD </h3> </br>
    <h2> Side </h2><h3> company_name {{ $company_name }} </h3> </br>

    <h2>Please go through this link : <a href="https://www.laxyo.org/quotation_form" >Here</a></h2>
   <!--  {{-- <h2>Please go through this link : <a href="http://purchase.laxyo.org/request_for_item" >Here</a></h2> --}} -->

 </div>
</body>
</html>

