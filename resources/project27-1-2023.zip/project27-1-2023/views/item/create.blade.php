@extends('../layouts.master')
@section('content')
<?php
    $s = substr(str_shuffle(str_repeat("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 5)), 0, 10);
?>  
<style>
    .form-control{
        border:none;
        border-bottom:1px solid rgba(0,0,0,.6);
        background-color:none !important; 
        border-radius:none !important;
    }

    .back-btn{
    background-color: rgb(5, 179, 132);
    border-color: rgb(5, 179, 132);
    font-size: 13px;
    font-weight: bold;
    text-transform: initial;
    width: 80px;
    color: #fff;
    border-radius: 6px;
    padding: 2px;
    text-align: center;
    text-decoration: none;
  }

  .back-btn:hover{
    opacity:0.7;
    padding: 2px;
    color: #fff !important;
  }


</style>
<div class="container-fluid">
    <a href="{{ '/item' }}" class="main-title-w3layouts mb-2 float-right back-btn">Back</a>
    <h5 class="main-title-w3layouts mb-2">Add Item</h5>
    <div class="card shadow mb-4">
        <div class="card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <strong>Warning!</strong> Please check your input code<br><br>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
                    <div class="row">
                        <div class="col-md-12" style="border-right: 1px solid">
            <form action="{{ route('item.store') }}" method="post">
                @csrf
                <div class="row">
                     <div class="form-group col-md-4">
                        <label>Part Number</label>
                        <input type="text" class="form-control" name="part_number" value="{{ old('part_number') }}">
                    </div>
                     <div class="form-group col-md-4">
                        <label>Item Name</label>
                        <input type="text" class="form-control" placeholder="Add Name" name="item_name" value="{{ old('item_name') }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Quantity</label>
                        <input type="text" class="form-control" placeholder="Add quantity" name="quantity" value="{{ old('quantity') }}">
                    </div>
                </div>

                 <div class="row">
                   <div class="form-group col-md-3">
                       <label>Select Unit</label>
                        <select name="unit_id" class="form-control">
                           @foreach($units as $unit)
                            <option value="{{$unit->name}}">{{$unit->name}}</option>
                           @endforeach
                        </select> 
                    </div>
                    <div class="form-group col-md-3">
                        <label>Item Rate</label>
                        <input type="number" class="form-control" placeholder="Add rate" name="rate" value="{{ old('number') }}">
                     </div>
                
                    <div class="form-group col-md-3">
                        <label>Add HSN Code</label>
                        <input type="text" class="form-control" placeholder="Add HSN Code" name="hsn_code" value="{{ old('hsn_code') }} ">
                    @error('hsn_code')
                        <span class="invalid-feedback d-block" role="alert">
                        <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    </div>
                    <div class="form-group col-md-3">
                        <label>Tax(GST)</label>
                        <input type="text" class="form-control" placeholder="Add gst" name="gst" value="{{ old('gst') }}">
                     </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-4">
                        <label>Buy/Sale/Both</label>
                        <select name="buy_sale_both" id="buy_sale_both" class="form-control">
                            <option disabled="" selected="">Select Buy/Sale/Both</option>
                            <option>Buy</option>
                            <option>Sale</option>    
                            <option>Both</option>    
                        </select>
                          
                        </select>
                    </div>
                     <div class="form-group col-md-4">
                        <label>Category</label>
                        <select name="category_id" id="category" class="form-control">
                            <option disabled="" selected="">Select Category</option>
                            @foreach ($category as $categorys)
                                <option value="{{ $categorys->id }}" {{ old('category_id') == $categorys->id ? 'selected' : '' }}>{{ $categorys->name }}</option>
                            @endforeach
                          
                        </select>
                    </div>
                
                    <div class="form-group col-md-4">
                        <label>Brand</label>
                       <select name="brand_id" id="brand_id" class="form-control">
                            <option disabled="" selected="">Select Category</option>
                             @foreach($brand as $brand)
                            <option value="{{$brand->name}}">{{$brand->name}}</option>
                           @endforeach
                        </select>
                     </div>
                </div>


                <div class="row">
                     <div class="form-group col-md-4">
                        <label>Vendor Name</label>
                        <input type="text" class="form-control" placeholder="Add vendor name" name="vendor_name" value="{{ old('vendor_name') }}">
                     </div>
                     <div class="form-group col-md-4">
                        <label>Vendor Location</label>
                        <input type="text" class="form-control" placeholder="Add vendor location" name="vendor_location" value="{{ old('vendor_location') }}">
                     </div>
                     <div class="form-group col-md-4">
                        <label>Product/Service</label>
                        <select name="product_service_name" id="product" class="form-control">
                            <option disabled="" selected="">Select</option>
                            <option>Product</option>
                            <option>Service</option>    
                        </select>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="form-group col-md-4">
                        <label>Current Stock</label>
                        <input type="text" class="form-control" placeholder="Add rate" name="current_stock" value="{{ old('current_stock') }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Min Stock Level</label>
                        <input type="number" class="form-control" placeholder="Add min stock" name="min_stock_level" value="{{ old('min_stock_level') }}">
                     </div>
                    <div class="form-group col-md-4">
                        <label>Max Stock Level</label>
                        <input type="number" class="form-control" placeholder="Add max stock" name="max_stock_level" value="{{ old('max_stock_level') }}">
                     </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Select Department</label>
                        <select name="dapartment" id="dapartment" class="form-control">
                            <option disabled="" selected="">Select Category</option>
                             @foreach($department as $departments)
                            <option value="{{$departments->name}}">{{$departments->name}}</option>
                           @endforeach
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Location</label>
                        <select name="location" class="form-control">
                            <option>Ratlam</option>
                            <option>Indore</option>
                            <option>Bhopal</option>
                        </select>
                    </div>
                </div>
                    
                <div class="row">
                        <div class="form-group col-md-6">
                        <label>Consumption</label>
                        <select name="consumption" class="form-control">
                            <option disabled="" selected="">Select level</option>
                            <option>level1</option>
                            <option>level2</option>
                            <option>level3</option>
                         
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Consumerable</label>
                        <input type="text" class="form-control" name="consumable" value="{{ old('consumable') }}" placeholder="consumable">
                     </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            </div>
          
          </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
    $('#OpenImgUpload').click(function(){ $('#imgupload').trigger('click'); });
</script>
@endsection

{{-- {{ route('excel_import') }} --}}