@extends('../layouts.master')
@section('content')
<style>
  .add-item-btn{
    background-color: rgb(5, 179, 132);
    border-color: rgb(5, 179, 132);
    font-size: 13px;
    font-weight: bold;
    text-transform: initial;
    width: 140px;
    margin-top: 22px;
    color: #fff;
    border-radius: 6px;
    padding: 6px;
    text-align: center;
    margin-left: 20px;
  }

  .add-item-btn:hover{
     padding: 6px;
     border-color: rgb(5, 179, 132) !important;
     background-color: #fff !important;
     color: rgb(5, 179, 132) !important;
  }

  .add-item-btn .dropdown-toggle{
     padding: 12px;
     border-color: rgb(5, 179, 132);
     background-color: #fff;
     color: rgb(5, 179, 132);
  }

  .form-control{
    border: 1px solid #9400D3;
    border-radius: 20px;
  }

  .item-menu{
    margin-top: 20px;
  }

  .item-menu .stock-head{
    display: inline-block;
    font-size: 11px;
    font-weight: bold;
    margin-bottom: 0px;
    color: rgb(12, 99, 127);
    padding: 0px 12px;
  }

  .bg-light{
    background-color: rgb(234, 255, 245) !important;
  }

  .item-menu .val{
    font-size: 22px !important;
    text-align: left;
    color: rgb(4, 139, 103) !important;
    margin-bottom: 0px;
    cursor: pointer;
  }

  .add-item-btn .dropdown-item:hover{
    color: rgb(5, 179, 132) !important;
    background: green;
  }   

</style>
<!-- Begin Page Content -->
<!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
 -->
<div class="container-fluid">
  <a href="{{ route('item.create') }}" class="main-title-w3layouts mb-2 float-right"><i class="fa fa-arrow-left"></i>Back</a>
  <h5 class="main-title-w3layouts mb-2">Item Listing</h5>
  <div class="card shadow mt-3">
    <div class="card-body">
      <div class="table-responsive">
        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
        @endif
        <form id="addForm">
          @csrf
            <div class="row">
              <div class="form-group col-md-5">
                  <select class="form-control" name="category" id="category">
                    <option selected="" disabled="" value="0">Filter By Category</option>
                    
                  </select>    
              </div>
              <div class="form-group col-md-5">
                  <select class="form-control" name="department" id="department">
                    <option selected="" disabled="" value="0">Filter By Department</option>
                   
                  </select>    
              </div>
              <div class="form-group col-md-2">
                <a class="float-right" href="{{ route('export_pdf') }}" title="PDF Download"><i class="fa fa-file-pdf-o" aria-hidden="true" style="font-size: 22px"></i></a>
                <a class="float-right" href="{{ route('excel_export') }}" title="Excel Download"><i class="fa fa-file-excel-o" aria-hidden="true" style="font-size: 22px; margin-right: 12px"></i></a>             
              </div>
            </div>
            <div class="row">
              <div class="col-md-4">
              <button type="button" class="btn dropdown-toggle add-item-btn"  data-toggle="dropdown">
      Add item
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="{{ route('item.create') }}">Single Item</a>
      <a class="dropdown-item" href="{{ url('export_pdf') }}">Multiple Items</a>  
    </div>
    <button type="button" class="btn btn-primary dropdown-toggle add-item-btn"  data-toggle="dropdown">
      Update Stock
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="#">Add Stock</a>
      <a class="dropdown-item" href="#">Reduce Stock</a>  
    </div>
  </div>
  <div class="col-md-5 bg-light">
    <div class="item-menu">
     <div class="row">
      <div class="col-md-3">
        <h4 class="stock-head">Stock Value</h4>
        <h2 class="val">35667</h2>
      </div>

      <div class="col-md-3">
         <h4 class="stock-head">Low Stock</h4>
        <h2 class="val">35667</h2>
      </div>

      <div class="col-md-3">
         <h4 class="stock-head">Excess Stock</h4>
        <h2 class="val">35667</h2>
      </div>

      <div class="col-md-3">
         <h4 class="stock-head">Inventory Dashboard</h4>
        <h2 class="val">35667</h2>
      </div>
     </div>
   

    </div>
  </div>
  <div class="col-md-3">
  </div>
              </div>
              <!-- <div class="row">
               
            </div> -->
        </form>
        <br>
        <div id="item-table">
            @include('item.table')
        </div>
        </div>
  </div>
</div>

<!-- script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.7.1.min.js"></script> -->
<!-- <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/jquery.dataTables.min.js"></script> -->
<script>
    $(document).ready(function(){
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
     });
      $('#category').on('change',function(){
           var catid = $(this).val();
          $.ajax({
                 type: "GET",
                 url: "{{ route('item-cat') }}?id="+catid,
                 success: function(res){
                  if(res){
                    //console.log(res);
                       $("#department").empty();
                       $("#department").append('<option value="">select department</option>');
                       $.each(res,function(index, rece){
                        $("#department").append('<option value='+rece.department_name['id']+'>'+rece.department_name['name']+'</option>')
                    });
                    
                  }
                }
                      });

      })

      $("#department").on('change', function(){
         var dep = $(this).val();
         var cat = $("#category").val();
         $.ajax({
                url: "{{  route('items-filter')}}",
                type: 'GET',
                // headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                data: {'dep':dep,'cat':cat},
                success: function (data) {
                 console.log(data);
               if(data){
                       $('#item-table').empty().html(data);
                }
                 
                }
            })
      });

    });
</script>
@endsection