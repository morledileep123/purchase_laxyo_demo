<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Bootstrap Table with Search Column Feature</title>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<style>

    tfoot {
        display: table-row-group;
    }
    tfoot input {
        width: 100%;
        padding: 3px;
        box-sizing: border-box;
    }

    table input{
        background: transparent;
        border-top-style: hidden;
        border-right-style: hidden;
        border-left-style: hidden;
        border-bottom-style: groove;
        background-color: #eee;
  }

    tfoot {
        display: table-header-group;
    }

  table input:focus-visible{
    outline: none;
  }
</style>
</head>
<body>
    <table id="example" class="display" style="width:100%">
         <thead>
            <tr style="background-color: #0c637f!important; color:#fff;">
           <!--    <th>S.No</th> -->
              <th>Item Code</th>
              <th>part_number</th>   
              <th>Item Name</th>
              <th>Unit</th>
              <th>Rate</th>
              <th>HSN Code</th>
              <th>GST</th>
              <th>Category</th>
              <th>Sub Category</th>
              <th>Brand</th>
              <th>Vendor Name</th>
              <th>vendor Location</th>  
              <th>Product/Service</th>
              <th>Current Stock</th>
              <th>Min Stock level</th>
              <th>Max Stock level</th>
              <th>Department</th>
              <th>Location</th>  
              <th>Buy/Sell/Both</th>
              <th>Consumption</th> 
              <th>Consumerable</th>                
              <th>Action</th>
            </tr>
          </thead>
        <tbody id="tbl-tbody">
            @if (!empty($items))
              @foreach ($items as $row)
              <tr>
                <!-- <td>{{ $row->id }}</td> -->
                <td>{{ $row->item_number }}</td>
                <td>{{ $row->part_number }}</td>
                <td>{{ $row->title }}</td>
                <td>{{ $row->unit->name }}</td> 
                <td>{{ $row->rate }}</td>  
                <td>{{ ($row->hsn_code) ? $row->hsn_code : 'N/A' }}</td>
                <td>{{ $row->gst }}</td>
                <td>{{ $row->category->name }}</td>
                <td>{{ $row->sub_category }}</td>
                <td>{{ $row->brand }}</td>
                <td>{{ $row->vendor_name }}</td>
                <td>{{ $row->vendor_location }}</td> 
                <td>{{ $row->product_service }}</td>
                <td>{{ $row->current_stock }}</td>
                <td>{{ $row->min_stock_level }}</td>
                <td>{{ $row->max_stock_level }}</td>
                <td>{{ $row->department_name }}</td>
                <td>{{ $row->location }}</td>
                <td>{{ $row->buy_sell_both }}</td>
                <td>{{ $row->consumption }}</td>
                <td>{{ $row->consumerable }}</td>                           
                <td>
                   @if(Auth::id() == 15 || Auth::id() == 16)
                  <form action="{{ route('item.destroy',$row->id) }}" method="POST">
                    <a class="btn btn-success" href="{{ route('item.show',$row->id) }}" title="Show"><i class="fa fa-eye" aria-hidden="true"></i></a>
                    <!-- <a class="btn btn-primary" href="{{ route('item.edit',$row->id) }}" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> -->
                    @csrf
                    @method('DELETE')
                  
                    <button type="submit" class="btn btn-danger" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
                  </form>
                    @endif
                </td>
              </tr>
              @endforeach
            @endif
          </tbody>
        <tfoot>
            <tr>
              <th>Item Code</th>
              <th>Item Name</th>
              <th>Unit</th>
              <th>Rate</th>
              <th>HSN Code</th>
              <th>GST</th>
              <th>Category</th>
              <th>Sub Category</th>
              <th>Brand</th>
              <th>Vendor Name</th>
              <th>Product/Service</th>
              <th>Current Stock</th>
              <th>Min Stock level</th>
              <th>Max Stock level</th>
              <th>Department</th>
              <th>Location</th>  
              <th>buy_sell_both</th>
              <th>Consumption</th> 
              <th>Consumerable</th>  
              <th>part_number</th>
              <th>vendor Location</th>                    
              <th>Action</th><th>Item Code</th>
              <th>part_number</th>   
              <th>Item Name</th>
              <th>Unit</th>
              <th>Rate</th>
              <th>HSN Code</th>
              <th>GST</th>
              <th>Category</th>
              <th>Sub Category</th>
              <th>Brand</th>
              <th>Vendor Name</th>
              <th>vendor Location</th>  
              <th>Product/Service</th>
              <th>Current Stock</th>
              <th>Min Stock level</th>
              <th>Max Stock level</th>
              <th>Department</th>
              <th>Location</th>  
              <th>Buy/Sell/Both</th>
              <th>Consumption</th> 
              <th>Consumerable</th>                 
              <th>Action</th>
            </tr>
        </tfoot>
    </table>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    $(document).ready(function () {
    // Setup - add a text input to each footer cell
    $('#example tfoot th').each(function () {
        var title = $(this).text();
        $(this).html('<input type="text" placeholder="Search ' + title + '" />');
    });
 
    // DataTable
    var table = $('#example').DataTable({
        initComplete: function () {
            // Apply the search
            this.api()
                .columns()
                .every(function () {
                    var that = this;
 
                    $('input', this.footer()).on('keyup change clear', function () {
                        if (that.search() !== this.value) {
                            that.search(this.value).draw();
                        }
                    });
                });
        },
    });

    $('tfoot').each(function () {
    $(this).insertAfter($(this).siblings('thead'));
});
});
</script>
</body>
</html>