<!DOCTYPE html>
<html>
<head>
    <title>Final Purchase Mail</title>
</head>
<body>
 <div>
  <h6>Hi {{ $uname }} ! <h6></br>
    <p>Super Admin have Finalized Quotation Send Quotation To Purchase on {{date('Y-m-d')}}</p></br>
    <p>Please go through this link : <a href="http://www.laxyo.org" >Here</a>

 </div>
</body>
</html>