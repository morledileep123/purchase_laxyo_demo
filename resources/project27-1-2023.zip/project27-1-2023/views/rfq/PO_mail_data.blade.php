<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<?php echo $tbl; ?>
<div class="container mt-3" style="border:1px solid">
	<h3 class="mt-4"><u>Terms and Conditions: </u></h3><br>
	<?php echo $tbl1; ?>
</div>