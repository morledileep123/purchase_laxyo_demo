<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Company_site_name;
use App\SiteName;
use App\unitofmeasurement;
use App\prch_quotationwise_requs;
use App\vendor;
use DB;

class GeneratePOController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $vendors = vendor::all();
        $sites = SiteName::all();
        $units = unitofmeasurement::get();
        $items = prch_quotationwise_requs::where('manager_status','=',1)->where('item_status','=',0)->pluck('item_name');
          
        return view('Generate_Purchase_Order.generate_po',compact('vendors','sites','units','items'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return $request;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function company_full_detail(Request $request)
    {
        $a = $request->post('a');
        $data = Company_site_name::where('id',$a)->pluck('full_address');
        return response()->json($data);
    }

    public function send_vendor(Request $request)
    {
        $svendor = $request->post('query');
        $svendors = vendor::where('id',$svendor)->get();

        $output = '';
        foreach($svendors as $row)
{
$output .= 'Company Name : '.$row->company .' 
Address 1 : '.$row->address1.'
Address 2 : '.$row->address2.'
Person Email : '.$row->company_email.'
Person Mobile : '.$row->company_mobile.'
';

}
        $output .= '';

        echo $output;

        // $userData = $svendors;
        // echo json_encode($svendors);

    }


    public function retrive_delivery_location(Request $request)
    {

        $location = $request->post('query');
        $locations = SiteName::where('id',$location)->pluck('name');

//         $output = '';
//         foreach($locations as $row)
// {
// $output .= 'Company Name : '.$row->name .'';

// }
//         $output .= '';

//         echo $output;

        return response()->json($locations);
        // echo json_encode($locations);
    }

    public function item_details(Request $request)
    {
        if($request->get('query'))
      {
        $query = $request->get('query');
        $data = prch_quotationwise_requs::where('item_name', 'ILIKE', "%{$query}%")->pluck('description');

        return response()->json($data);
      }

    }


    // public function item_details(Request $request)
    // {
    //     $item_name = $request->post('query');
    //     $data = prch_quotationwise_requs::where('item_name',$item_name)->get();

    //     $output = '';
    //         foreach($data as $row)
    //         {
    //         $output .= ''.$row->description.'';
    //         }
    //     $output .= '';

    //     return response()->json($output);

    // }

    public function company_sign_pics(Request $request)
    {
        $query = $request->get('sign');
        $data = Company_site_name::where('id',$query)->pluck('image');
        return response()->json($data);
    }
}
