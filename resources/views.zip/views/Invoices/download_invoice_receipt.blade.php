<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <title>Invoice</title>
  </head>
  <style>

  * {
    margin: 0;
    padding: 0;
  }

  #watermark{
     position: fixed;
     bottom:   10cm;
     left:     5.5cm;
     width:    8cm;
     height:   8cm;
     z-index:  -1000;
   }

  footer{
    position: fixed; 
    bottom: 20px; 
    left: 0cm; 
    right: 0cm;
    height: 2cm;                      
  }
  .column {
  float: left;
  width: 33.33%;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

.container {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
</style>
  <body>   
  
  <div class="container"> 
    <div class="row mt-4">
      <h4 style="text-align:center;padding-top:12px;">GRR</h4>
    </div>
    <br>

    <div>
      <p>Invoice code :  {{$data->invoice_no}}</p>
      <p>GRR code :  {{$data->grn_no}}</p>
      <p>Invoice date : {{date('d-m-Y', strtotime($data->invoice_date)) }}</p>
      <p>Delivery Date : {{date('d-m-Y', strtotime($data->delivery_date))}}</p>
    </div>
    <br>
   
    <div class="row">
      <div class="column">
        <small>Vendor Detail</small>
          @if(!empty($data->vender_company))        
            <h5>{{$data->vender_company}}</h5> 
            <h5>{{$data->vender_email}}</h5>
            <h5>{{$data->vender_address1}}</h5>
            <h5>{{$data->vender_address2}}</h5>
            <h5>{{$data->vender_state}}</h5>
            <h5>{{$data->vender_city}}</h5> 
            <h5>{{$data->vender_person_name}}</h5> 
            <h5>{{$data->vender_person_email}}</h5> 
            <h5>{{$data->vender_person_no}}</h5> 
          @else
            <h5 style="white-space: pre-line">{{$data->vender_detail}}</h5>        
          @endif
      </div>
      <div class="column">
        <small>Delivery Location</small>
        <h5>{{$data->delivery_address}}</h5>
      </div>
      <div class="column">
        <small>Company Name</small>
        <h5>{{$data->company_location}}</h5>
      </div>
    </div>

    <br>

    <div class="row">
      <div class="col-12">
        <div class="table-responsive">
          <table class="table" border="2">
            <thead style="background-color:#f2f2f2">
              <tr>
                <th>S.N</th>
                <th>Item Name</th>                       
                <th>Unit</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Tax</th>
                <th>Discount</th>
                <th>Sub total</th>
              </tr>
            </thead>
            <tbody>
              @php $i=1; @endphp
              @foreach($items as $key => $row)
              <tr>
                <td>{{$i++}}</td>
                <td>{{$row->invoice_product}}</td>
                <td>{{$row->quantity_unit}}</td>
                <td>{{$row->description}}</td>
                <td>{{$row->product_qty}}</td>
                <td>{{$row->product_price}}</td>
                <td>{{$row->product_tax}}</td>
                <td>{{$row->product_discount}}</td>
                <td>{{$row->product_subtotal}}</td>
              </tr>
              @endforeach
            </tbody>
          </table>          
        </div>
      </div>
    </div>
    <br> 

    <div class="row">
      <div class="column">
        <p style="white-space: pre-line"><strong>Comment : </strong>{{$data->comments}}</p> 
      </div>
      <div class="column" style="float:right;">
        <p><strong>Final Amount : </strong>{{$data->grand_total}}</p> 
        <p><strong>Final Amount In words : </strong>{{$data->amount_rupees}}</p> 
      </div>
    </div>
    <br>
  </div>
   
  </body>
</html>
