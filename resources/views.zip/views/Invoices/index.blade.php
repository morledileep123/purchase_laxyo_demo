@extends('../layouts.master')
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" rel="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.colVis.min.js"></script>
<style>
  .modal-autoheight .modal-body {
    position: relative;
    overflow-y: auto;
    min-height: 300px !important;
   
  }
</style>
@section('content')

<!-- Modal Delete -->
<div class="modal fade" id="delete_invoice" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <form action="{{route('GoodsReceivedNote.destroy', 'id')}}" method="POST">
      @csrf
      @method('DELETE')
      <div class="modal-content">
        <div class="modal-header">
          <p class="modal-title" id="exampleModalCenterTitle">Delete GRR</p>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <strong>Are you sure you want to delete this GRR</strong>
          <input type="hidden" name="invoice_id" id="invoice_id">
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger">Yes , Delete</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Modal Reject Reasion-->
<div class="modal fade" id="DeleteReasonModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-autoheight" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Declined Reason</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <textarea name="reject" class="form-control" id="reject" rows="10%" cols="54%" readonly></textarea>
      </div>
    </div>
  </div>
</div>



<div class="container">
  @if (Session::has('success'))
    <div class="alert alert-success alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert">
          <i class="fa fa-times"></i>
      </button>
      <strong>Success !</strong> {{ session('success') }}
    </div>
  @endif
</div>
<div class="container">
  @if (Session::has('success_mail'))
    <div class="alert alert-success alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert">
          <i class="fa fa-times"></i>
      </button>
      <strong>Success !</strong> {{ session('success_mail') }}
    </div>
  @endif
</div>
<div class="container">
  @if(Session::has('delete'))
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert">
            <i class="fa fa-times"></i>
        </button>
        <strong>Success !</strong> {{ session('delete') }}
    </div>
  @endif
</div>

<div class="container-fluid">
  <div class="card">
  <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <h4>GRR Lists</h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <div class="card-header" style="padding:4px; border:none;">
                <a href="{{ route('GoodsReceivedNote.create') }}" class="btn btn-success">Create New GRR</a>
                <a href="{{ url()->previous() }}" class="btn btn-secondary">Back</a>
              </div>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" style="width: 50%">
                  <a class="nav-link text-center active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"><b>Generate GRR</b></a>
                </li>
                <li class="nav-item" style="width: 50%">
                  <a class="nav-link text-center" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false"><b>Send GRR</b></a>
                </li>
              </ul>
              <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                  <div class="table-responsive">
                  <table class="table table-bordered table-hover" id="inv-table">
                  <thead>
                  <tr>
                    <th>S No</th>
                    <th>Invoice no</th>
                    <th>GRR no</th>
                    <th>Vendor</th>
                    <th>Delivery date</th>
                    <th>Invoice date</th>                    
                    <th>Action</th>
                    
                  </tr>
                  </thead>
                  <tbody>
                  @php $i=1; @endphp
                  @foreach($invoices as $row)
                    <tr>
                      <td>{{ $i++ }}</td>
                      <td>{{ $row->invoice_no }}</td>                                  
                      <td>{{ $row->grn_no }}</td> 

                      @if(!empty($row->vender_company))        
                        <td>{{$row->vender_company}}</td>  
                      @else
                        <td style="white-space: pre-line">{{$row->vender_detail}}</td>        
                      @endif 

                      <td>{{ $row->delivery_date }}</td>
                      <td>{{ $row->invoice_date }}</td>
                  
                      <td>
                        <div class="btn-group">
                          <button type="button" class="btn btn-secondary dropdown-toggle dropdown-icon" data-toggle="dropdown">Action
                          </button>
                          <div class="dropdown-menu">                           
                            <a class="dropdown-item" href="{{route('GoodsReceivedNote.show',$row->id )}}"><i class="fa fa-eye" aria-hidden="true"></i> View GRR</a>
                            <a class="dropdown-item" href="{{url('invoicedownloaduser',$row->id )}}"><i class="fa fa-file-pdf" aria-hidden="true"></i> Download</a>
                            <a class="dropdown-item" href="{{route('GoodsReceivedNote.edit',$row->id )}}"><i class="fa fa-edit" aria-hidden="true"></i> Edit GRR</a>
                            <button type="button" class="dropdown-item delete_invoice" value="{{$row->id}}"><i class="fa fa-trash " aria-hidden="true"></i> Delete GRR</button>
                          </div>
                        </div>
                      </td>
  
                    </tr>
                  @endforeach
                  
                  </tbody>
                  
                  </table>
                  </div>
                </div>

                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                  <div class="table-responsive">
                  <table class="table table-bordered table-hover" id="inv-table">
                  <thead>
                  <tr>
                    <th>S No</th>
                    <th>Invoice no</th>
                    <th>GRR no</th>
                    <th>Vendor</th>
                    <th>Delivery date</th>
                    <th>Invoice date</th>
                    <th>Status</th>
                    <th>Action</th>                    
                  </tr>
                  </thead>
                  <tbody>
                  @php $i=1; @endphp
                  @foreach($invoices_send as $row)
                    <tr>
                      <td>{{ $i++ }}</td>
                      <td>{{ $row->invoice_no }}</td>                                  
                      <td>{{ $row->grn_no }}</td> 

                      @if(!empty($row->vender_company))        
                        <td>{{$row->vender_company}}</td>  
                      @else
                        <td style="white-space: pre-line">{{$row->vender_detail}}</td>        
                      @endif 

                      <td>{{ $row->delivery_date }}</td>
                      <td>{{ $row->invoice_date }}</td>
                      
                      @if($row->reject != null)
                      <td><button type="button" class="form-control border border-danger text-danger DeleteReason" value="{{$row->reject}}">{{'Declined'}}</button></td>
                      
                      @elseif($row->admin_status == 1 && $row->manager_aprove == 1 && $row->manager_status == 1 && $row->user_send_grr == 1)
                        <td class="text-success">{{'Approve'}}</td>
                       
                      @else
                        <td class="text-primary">{{'Processing'}}</td>
                      @endif
                      
                      
                      <td>
                        <div class="btn-group">
                          <button type="button" class="btn btn-secondary dropdown-toggle dropdown-icon" data-toggle="dropdown">Action
                          </button>
                          <div class="dropdown-menu">                           
                            <a class="dropdown-item" href="{{url('invoicedownloaduser',$row->id )}}"><i class="fa fa-file-pdf" aria-hidden="true"></i> Download</a>
                          </div>
                        </div>
                      </td>
  
                    </tr>
                  @endforeach
                  
                  </tbody>
                  
                  </table>
                  </div>
                </div>
                
              </div>                
              
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
</div>

<script>
  $(document).ready(function(){
    $('#inv-table').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'columnsToggle'
        ]
    });
    $('#myTab a').on('click', function (e) {
      e.preventDefault()
      $(this).tab('show')
    });

    $('.delete_invoice').click(function(e){
      e.preventDefault();

      var id = $(this).val();
      
      $('#invoice_id').val(id);

      $('#delete_invoice').modal('show');

    });

    $('.DeleteReason').click(function(e){
      e.preventDefault();

      var reject = $(this).val();
      // alert(reject);
      $('#reject').val(reject);

      $('#DeleteReasonModal').modal('show');

    });

  });
</script>
<script type="text/javascript">
  $(function() {
    if ($(".modal-autoheight").length => 0) {
      $(".modal").on("show.bs.modal", resize);
      $(window).on("resize", resize);
    }
  });


function resize() {
  var winHeight = $(window).height();
  $(".modal-autoheight .modal-body").css({
    width: "auto",
    height: (winHeight - 200) + "px"
  });
}
</script>
@endsection