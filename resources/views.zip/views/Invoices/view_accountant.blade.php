<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <title>GRR</title>
  </head>
  <body>

    <div class="wrapper">
  
      <nav class="navbar navbar-light bg-light justify-content-between" style="background-color: #fff;">
        <div class="container">
          @if($data->admin_approve == 1)
          <a href="{{url('sendapprove',$data->id)}}" type="button" class="btn btn-success send_purchase_order" style="color:white">Approval for amount</a>
          @else
          @endif 

          <a href="/">
          <img src="{{asset('assets/img/laxyo_pic.png')}}" class="thumbnail img-responsive" alt="Laxyo Energy LTD" style="max-width: 60%;">
        </a>

        <div class="form-inline">
          <div class="btn-group">
            <button type="button" class="btn btn-secondary dropdown-toggle dropdown-icon" data-toggle="dropdown">Action
            </button>
            <div class="dropdown-menu">  
              <a class="dropdown-item" href="javascript:printdoc();" onclick="window.print()" href="#"><i class="fa fa-print" aria-hidden="true"></i> Print</a>  
              <a class="dropdown-item" href="{{url('invoicedownloadaccountant',$data->id )}}"><i class="fa fa-file-pdf" aria-hidden="true"></i>PDF Download</a>                       
            </div>
          <a href="{{ url()->previous() }}" class="btn btn-secondary ml-2">Back</a>
          </div>
        </div>
        </div>
      </nav>
      <!-- /.navbar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    
    <!-- /.content-header -->

    <!-- Main content -->
    <section>
      <div class="container my-3">
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-body" style="padding:0px;">
                            
                <div class="container-fluid">
                  <div class="row mt-4">
                    <h4 style="text-align:center; display: block; margin: 0 auto; margin-top: 20px !important;">GRR</h4>
                  </div>
                  <br>

                  <div class="container-fluid">
                    <div>
                      <p>Invoice no :  {{$data->invoice_no}}</p>
                      <p>GRR no :  {{$data->grn_no}}</p>
                      <p>Invoice date : {{date('d-m-Y', strtotime($data->invoice_date)) }}</p>
                      <p>Delivery Date : {{date('d-m-Y', strtotime($data->delivery_date))}}</p>
                    </div>
                 
                    <div class="row">
                      <div class="col-md-4">
                        <small>Vendor Detail</small>

                        @if(!empty($data->vender_company))        
                          <h6>{{$data->vender_company}}</h6> 
                          <h6>{{$data->vender_email}}</h6>
                          <h6>{{$data->vender_address1}}</h6>
                          <h6>{{$data->vender_address2}}</h6>
                          <h6>{{$data->vender_state}}</h6>
                          <h6>{{$data->vender_city}}</h6> 
                          <h6>{{$data->vender_person_name}}</h6> 
                          <h6>{{$data->vender_person_email}}</h6> 
                          <h6>{{$data->vender_person_no}}</h6> 
                        @else
                          <h6 style="white-space: pre-line">{{$data->vender_detail}}</h6>        
                        @endif

                      </div>
                      <div class="col-md-4">
                        <small>Delivery Location</small>
                        <p>{{$data->delivery_address}}</p>
                      </div>
                      <div class="col-md-4">
                        <small>Company Name</small>
                        <p style="white-space: pre-line">{{$data->company_location}}</p>
                      </div>
                    </div>
                    <br>
                  </div>

                  <div class="row">
                    <div class="col-12">
                      <div class="table-responsive">
                        <table class="table" border="2">
                          <thead style="background-color:#f2f2f2">
                            <tr>
                              <th>S.N</th>
                              <th>Item Name</th>                       
                              <th>Unit</th>
                              <th>Description</th>
                              <th>Quantity</th>
                              <th>Price</th>
                              <th>Tax</th>
                              <th>Discount</th>
                              <th>Sub total</th>
                            </tr>
                          </thead>
                          <tbody>
                            @php $i=1; @endphp
                            @foreach($items as $key => $row)
                            <tr>
                              <td>{{$i++}}</td>
                              <td>{{$row->invoice_product}}</td>
                              <td>{{$row->quantity_unit}}</td>
                              <td>{{$row->description}}</td>
                              <td>{{$row->product_qty}}</td>
                              <td>{{$row->product_price}}</td>
                              <td>{{$row->product_tax}}</td>
                              <td>{{$row->product_discount}}</td>
                              <td>{{$row->product_subtotal}}</td>
                            </tr>
                            @endforeach
                          </tbody>
                        </table>          
                      </div>
                    </div>
                  </div>
                  <br> 

                  <div class="container-fluid">
                    <div class="row">
                    <div class="col-md-6">
                      <p><strong>Comment : </strong>{{$data->comments}}</p> 
                    </div>
                    <div class="col-md-6">
                      <p><strong>Final Amount : </strong>{{$data->grand_total}}</p> 
                      <p><strong>Final Amount In words : </strong>{{$data->amount_rupees}}</p> 
                    </div>
                    </div>
                  <br>
                  </div>
                  
                  </div>
                  
                             
                </div>
            </div>

          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
      </section>
   
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


</div>
<!-- ./wrapper -->
    
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>


</body>
</html>


