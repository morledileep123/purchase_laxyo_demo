{{-- @extends('layouts.master')

@section('content')
<style type="text/css"> 
	.welcome-db{
			padding: 20%;
	    text-align: center;
	    color: #000;
	    background: beige;
	}
</style> --}}

{{-- <!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
</div> --}}

{{-- <div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-body welcome-db">
            <h3>Welcome <b>{{ ucwords(Auth::user()->name) }}</b> <br> Laxyo Purchase Dashboard</h3>
				</div>
    </div>
</div>
 --}}
{{-- <!-- Content Row -->
<div class="row">

  <!-- Earnings (Monthly) Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-primary shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Earnings (Monthly)</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800">$40,000</div>
          </div>
          <div class="col-auto">
            <i class="fas fa-calendar fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Earnings (Monthly) Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-success shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Earnings (Annual)</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800">$215,000</div>
          </div>
          <div class="col-auto">
            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Earnings (Monthly) Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-info shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Tasks</div>
            <div class="row no-gutters align-items-center">
              <div class="col-auto">
                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">50%</div>
              </div>
              <div class="col">
                <div class="progress progress-sm mr-2">
                  <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-auto">
            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Pending Requests Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-warning shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pending Requests</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
          </div>
          <div class="col-auto">
            <i class="fas fa-comments fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> 

<!-- Content Row  -->

<div class="row">

  <!-- Area Chart -->
  <div class="col-xl-8 col-lg-7">
    <div class="card shadow mb-4">
      <!-- Card Header - Dropdown -->
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Earnings Overview</h6>
        <div class="dropdown no-arrow">
          <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
            <div class="dropdown-header">Dropdown Header:</div>
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </div>
      </div>
      <!-- Card Body -->
      <div class="card-body">
        <div class="chart-area">
          <canvas id="myAreaChart"></canvas>
        </div>
      </div>
    </div>
  </div>

  <!-- Pie Chart -->
  <div class="col-xl-4 col-lg-5">
    <div class="card shadow mb-4">
      <!-- Card Header - Dropdown -->
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Revenue Sources</h6>
        <div class="dropdown no-arrow">
          <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
            <div class="dropdown-header">Dropdown Header:</div>
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </div>
      </div>
      <!-- Card Body -->
      <div class="card-body">
        <div class="chart-pie pt-4 pb-2">
          <canvas id="myPieChart"></canvas>
        </div>
        <div class="mt-4 text-center small">
          <span class="mr-2">
            <i class="fas fa-circle text-primary"></i> Direct
          </span>
          <span class="mr-2">
            <i class="fas fa-circle text-success"></i> Social
          </span>
          <span class="mr-2">
            <i class="fas fa-circle text-info"></i> Referral
          </span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Content Row -->
<div class="row">

  <!-- Content Column -->
  <div class="col-lg-6 mb-4">

    <!-- Project Card Example -->
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Projects</h6>
      </div>
      <div class="card-body">
        <h4 class="small font-weight-bold">Server Migration <span class="float-right">20%</span></h4>
        <div class="progress mb-4">
          <div class="progress-bar bg-danger" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <h4 class="small font-weight-bold">Sales Tracking <span class="float-right">40%</span></h4>
        <div class="progress mb-4">
          <div class="progress-bar bg-warning" role="progressbar" style="width: 40%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <h4 class="small font-weight-bold">Customer Database <span class="float-right">60%</span></h4>
        <div class="progress mb-4">
          <div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <h4 class="small font-weight-bold">Payout Details <span class="float-right">80%</span></h4>
        <div class="progress mb-4">
          <div class="progress-bar bg-info" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <h4 class="small font-weight-bold">Account Setup <span class="float-right">Complete!</span></h4>
        <div class="progress">
          <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
      </div>
    </div>

    <!-- Color System -->
    <div class="row">
      <div class="col-lg-6 mb-4">
        <div class="card bg-primary text-white shadow">
          <div class="card-body">
            Primary
            <div class="text-white-50 small">#4e73df</div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 mb-4">
        <div class="card bg-success text-white shadow">
          <div class="card-body">
            Success
            <div class="text-white-50 small">#1cc88a</div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 mb-4">
        <div class="card bg-info text-white shadow">
          <div class="card-body">
            Info
            <div class="text-white-50 small">#36b9cc</div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 mb-4">
        <div class="card bg-warning text-white shadow">
          <div class="card-body">
            Warning
            <div class="text-white-50 small">#f6c23e</div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 mb-4">
        <div class="card bg-danger text-white shadow">
          <div class="card-body">
            Danger
            <div class="text-white-50 small">#e74a3b</div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 mb-4">
        <div class="card bg-secondary text-white shadow">
          <div class="card-body">
            Secondary
            <div class="text-white-50 small">#858796</div>
          </div>
        </div>
      </div>
    </div>

  </div>

  <div class="col-lg-6 mb-4">

    <!-- Illustrations -->
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Illustrations</h6>
      </div>
      <div class="card-body">
        <div class="text-center">
          <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src="/themes/sb-admin2/img/undraw_posting_photo.svg" alt="">
        </div>
        <p>Add some quality, svg illustrations to your project courtesy of <a target="_blank" rel="nofollow" href="https://undraw.co/">unDraw</a>, a constantly updated collection of beautiful svg images that you can use completely free and without attribution!</p>
        <a target="_blank" rel="nofollow" href="https://undraw.co/">Browse Illustrations on unDraw &rarr;</a>
      </div>
    </div>

    <!-- Approach -->
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Development Approach</h6>
      </div>
      <div class="card-body">
        <p>SB Admin 2 makes extensive use of Bootstrap 4 utility classes in order to reduce CSS bloat and poor page performance. Custom CSS classes are used to create custom components and custom utility classes.</p>
        <p class="mb-0">Before working with this theme, you should become familiar with the Bootstrap framework, especially the utility classes.</p>
      </div>
    </div>

  </div>
</div> --}}

{{-- @endsection --}}


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laxyo - Purchase</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">

  <style type="text/css">
    .welcome-db{
        padding: 12%;
        text-align: center;
        color: #000;
        background: beige;
    }
  </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge">15</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">15 Notifications</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i> 4 new messages
            <span class="float-right text-muted text-sm">3 mins</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-users mr-2"></i> 8 friend requests
            <span class="float-right text-muted text-sm">12 hours</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-file mr-2"></i> 3 new reports
            <span class="float-right text-muted text-sm">2 days</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      
        <!-- Nav Item - User Information -->
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span class="mr-2 d-none d-lg-inline text-gray-600 small">{{ Auth::user()->name }}</span>
          
        </a>
        <!-- Dropdown - User Information -->
        {{-- <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>{{ __('Logout') }}</a>
          <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
              @csrf
          </form>
        </div> --}}
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-controlsidebar-slide="true" href="#" role="button">
          <i class="fas fa-th-large"></i>
        </a>
      </li>
    </ul>
  </nav>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="http://www.laxyo.org/#/" class="brand-link" style="background-color: whitesmoke;">
    <img class="rounded mx-auto d-block img-fluid" src="{{asset('assets/img/laxyo_pic.png')}}" height="25">
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group mt-3" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
  @role("purchase_superadmin")
    <!-- <li class="nav-item">
        <a class="nav-link" href="{{ '/role' }}">
          <i class="fa fa-lock" aria-hidden="true"></i>
          <span>Assign Role</span></a>
      </li>
    
      <li class="nav-item">
        <a class="nav-link" href="{{ '/members' }}">
          <i class="fa fa-plus" aria-hidden="true"></i>
          <span>Members</span></a>
      </li> -->
      

    <li class="nav-item">
      <a href="{{ route('item.index') }}" class="nav-link">
        <i class="nav-icon fas fa-th"></i>
        <p>Items</p>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="{{ route('vendor.index') }}" class="nav-link">
        <i class="nav-icon fas fa-copy"></i>
        <p>Vendors</p>
      </a>
    </li>   

    <li class="nav-item">
      <a class="nav-link" href="{{ route('purchase.index') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Purchase Order (PO)</span>
      </a>
    </li>
    
    {{-- <li class="nav-item">
      <a class="nav-link" href="{{ url('superadmin_grr_index') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Request for GRR</span></a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="{{ route('store_item.index') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Warehouse Item</span></a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="{{ route('items_approval') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Request for Items</span></a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="{{ route('quotation_received_leveltwo') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Received Quotation</span></a>
    </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ route('pucharse-details') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Puchase Detail</span></a>
    </li> --}}
    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading" style="color:#fff; font-weight: 600;">Setting</div>
    <li class="nav-item">
      <a href="#" class="nav-link">
        <i class="nav-icon fas fa-edit"></i>
        <p>Masters
          <i class="fas fa-angle-left right"></i>
        </p>
      </a>
      <ul class="nav nav-treeview">
        <li class="nav-item">
          <a href="{{ '/um' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Units of Measurement</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{ '/category' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Items Category</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{ '/subcategory' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Items Subcategory</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{ '/warehouse' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Warehouses</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{ '/gst_state_code' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>GST States</p>
          </a>
        </li>
         <li class="nav-item">
          <a href="{{ '/department' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Department</p>
          </a>
        </li>
      </ul>
    </li>

  <!-- Divider -->
  @endrole

   @role("purchase_accountant")
    <li class="nav-item">
      <a class="nav-link" href="{{ url('accountant_grr_index') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>GRR</span></a>
    </li>    
    
  @endrole

 @role("purchase_admin")
    <li class="nav-item">
      <a class="nav-link" href="{{ url('admin_view') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>RFI by Manager</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="{{ url('vendor_quotation') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Quotation</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="{{ url('generate_po') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Purchase Order (PO)</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="{{ url('item') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Item</span></a>
    </li> 
    <li class="nav-item">
      <a class="nav-link" href="{{ url('vendor') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Vendor</span></a>
    </li>

    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading" style="color:#fff; font-weight: 600;">Setting</div>
    <li class="nav-item">
      <a href="#" class="nav-link">
        <i class="nav-icon fas fa-edit"></i>
        <p>Masters
          <i class="fas fa-angle-left right"></i>
        </p>
      </a>
      <ul class="nav nav-treeview">
        <li class="nav-item">
          <a href="{{ '/um' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Units of Measurement</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{ '/category' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Items Category</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{ '/subcategory' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Items Subcategory</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{ '/warehouse' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Warehouses</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{ '/gst_state_code' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>GST States</p>
          </a>
        </li>
         <li class="nav-item">
          <a href="{{ '/department' }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Department</p>
          </a>
        </li>
      </ul>
    </li>

    {{-- <li class="nav-item">
      <a class="nav-link" href="{{ route('quotation_received_levelone') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Received Quotation</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="{{ route('store_item.index') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Warehouse Items</span></a>
    </li> --}}
    
  @endrole

  @role("purchase_manager")
  <li class="nav-item">
    <a class="nav-link" href="{{ url('manager_view') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>RFI by Users</span></a>
  </li>
  
  <li class="nav-item">
    <a class="nav-link" href="{{ url('manager_grr_index') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Request For GRR</span></a>
  </li>
{{-- 
  <li class="nav-item">
    <a class="nav-link" href="{{ route('manager_request') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Request For Item</span></a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ route('disable-to-dispatch') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Purchase Item(Filtered)</span></a>
  </li> --}}

  <!-- <li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
      <i class="fas fa-fw fa-cog"></i>
      <span>Request For Item</span>
    </a>
    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionSidebar">
      <div class="bg-white py-2 collapse-inner rounded">
        <a class="collapse-item" href="{{ route('request_for_item.create') }}">Create RFI</a>
        <a class="collapse-item" href="{{ route('request_for_item.index') }}">RFI Listing</a>
      </div>
    </div>
  </li> -->
{{--   <li class="nav-item">
    <a class="nav-link" href="{{ route('store_item.index') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Warehouse Items</span></a>
  </li>


  <li class="nav-item">
    <a class="nav-link" href="{{ route('rfq.index') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>View Request Quotations</span></a>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="{{ route('approval_quotation') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Approval Quotation</span></a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ route('mo-req-item') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Move Requested Items</span></a>
  </li> --}}
  @endrole

  @role("purchase_user")
  <li class="nav-item">
      <a href="#" class="nav-link">
        <i class="nav-icon fas fa-edit"></i>
        <p>Request For Items (RFI)
          <i class="fas fa-angle-left right"></i>
        </p>
      </a>
      <ul class="nav nav-treeview">
        
        <li class="nav-item">
          <a href="{{ route('request_for_item.create') }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>Create RFI</p>
          </a>
        </li>
         <li class="nav-item">
          <a href="{{ route('request_for_item.index') }}" class="nav-link">
            <i class="far fa-circle nav-icon"></i>
            <p>RFI Listing</p>
          </a>
        </li>
      </ul>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="{{ route('GoodsReceivedNote.index') }}">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>GRR/Invoice</span></a>
    </li>
  @endrole

  @role("store_admin")
  <li class="nav-item admin_css">
    <a class="nav-link" href="{{ route('store_item.index') }}">
      <i class="fas fa-fw fa-shopping-cart"></i>
      <span class="admin_css">Items</span>
    </a>
  </li>
  
  <li class="nav-item">
    <a class="nav-link" href="{{ route('store_management.index') }}">
      <i class="fas fa-fw fa-chart-area admin_css"></i>
      <span class="admin_css">PO Received</span></a>
  </li>
    <li class="nav-item">
    <a class="nav-link" href="{{ route('item_of_stock') }}">
      <i class="fas fa-fw fa-chart-area admin_css"></i>
      <span class="admin_css">Your Stock</span></a>
  </li>
   <li class="nav-item">
    <a class="nav-link" href="{{ route('un_item_of_stock') }}">
      <i class="fas fa-fw fa-chart-area admin_css"></i>
      <span class="admin_css">Req Item unable</span></a>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="{{ route('view_grn') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span class="admin_css">Generate GRN</span></a>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="{{ route('receiving') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span class="admin_css">Stock Transfer</span></a>
  </li>
  {{-- <li class="nav-item">
    <a class="nav-link" href="{{ route('approve_dc') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span class="admin_css">Approve Stock Transfer</span></a>
  </li> --}}
  <li class="nav-item">
    <a class="nav-link" href="{{ route('users') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span class="admin_css">User Management</span></a>
  </li>
  @endrole
  @role(["purchase_superadmin","purchase_admin"])
  {{-- <li class="nav-item">
    <a class="nav-link" href="{{ route('approve_dc') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span class="admin_css">Approve Stock Transfer</span></a>
  </li> --}}
  @endrole

  <!-- @role("ratlam_warehouse"||"indore_warehouse")
  <li class="nav-item">
    <a class="nav-link" href="{{ route('store_item.index') }}">
      <i class="fas fa-fw fa-shopping-cart"></i>
      <span>Items</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="{{ route('store_management.index') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>PO Received</span></a>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="{{ route('view_grn') }}">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Generate GRN</span></a>
  </li>
  @endrole -->


        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">       
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12 connectedSortable">
            <!-- Custom tabs (Charts with tabs)-->
            <div class="card">
              
              <div class="card-body welcome-db">
                <div class="tab-content p-0">
                  <!-- Morris chart - Sales -->
                    <h3>Welcome <b>{{ ucwords(Auth::user()->name) }}</b> <br> Laxyo Purchase Dashboard</h3>
                    {{-- <div class="container-fluid">
                        <div class="card shadow mb-4">
                            <div class="card-body welcome-db">
                                <h3>Welcome <b>{{ ucwords(Auth::user()->name) }}</b> <br> Laxyo Purchase Dashboard</h3>
                            </div>
                        </div>
                    </div>
                     --}}
                  <div class="chart tab-pane active" id="revenue-chart"
                       style="position: relative; height: 300px;">
                      <canvas id="revenue-chart-canvas" height="300" style="height: 300px;"></canvas>
                  </div>

                  <div class="chart tab-pane" id="sales-chart" style="position: relative; height: 300px;">
                    <canvas id="sales-chart-canvas" height="300" style="height: 300px;"></canvas>
                  </div>
                </div>
              </div><!-- /.card-body -->
            </div>
            <!-- /.card -->
            
          </section>
          <!-- /.Left col -->
       
          <!-- right col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.2.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
</body>
</html>

