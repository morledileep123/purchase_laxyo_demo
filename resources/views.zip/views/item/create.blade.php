@extends('../layouts.master')
@section('content')
<div class="container-fluid">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <h4>Add Item</h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <a href="{{ url()->previous() }}" class="btn btn-secondary btn-sm">Back</a>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <div class="card shadow mb-4">
        <div class="card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <strong>Warning!</strong> Please check your input code<br>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
                    <div class="row">
                        <div class="col-md-12">
            <form action="{{ route('item.store') }}" method="post" class="create-form">
                @csrf
                <div class="row">
                     <div class="form-group col-md-6">
                        <label>Part Number</label>
                        <input type="text" class="form-control" value="{{ old('part_number') }} " name="part_number">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Item Name<span style="color:red"> *</span></label>
                        <input type="text" class="form-control" placeholder="Add Name" name="item_name" value="{{ old('item_name') }}">
                    </div>
                     </div>
                   

                 <div class="row">
                     <div class="form-group col-md-6">
                        <label>Description<span style="color:red"> *</span></label>
                        <input type="text" class="form-control" placeholder="Add Description" name="description" value="{{ old('description') }}">
                </div>
                <div class="form-group col-md-6">
                       <label>Select Unit<span style="color:red"> *</span></label>
                        <select name="unit_id" id="unit" class="form-control">
                            <option disabled="" selected="" hidden>Select UOM</option>
                            @foreach ($units  as $unit)
                                <option value="{{ $unit->name }}" {{ old('unit_id') == $unit->name ? 'selected' : '' }}>{{ $unit->name }}</option>
                            @endforeach  
                        </select>
                    </div>
                    </div>

                      
               

                <div class="row"> 
                 <div class="form-group col-md-6">
                        <label>Item Rate</label>
                        <input type="number" class="form-control" placeholder="Add rate" name="rate" value="{{ old('rate') }}">
                     </div> 
                    <div class="form-group col-md-6">
                        <label>Add HSN Code</label>
                        <input type="text" class="form-control" placeholder="Add HSN Code" name="hsn_code" value="{{ old('hsn_code') }}">
                 @error('hsn_code')
                    <span class="invalid-feedback d-block" role="alert">
                    <strong>{{ $message }}</strong>
                    </span>
                  @enderror
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Tax(GST%)</label>
                        <input type="text" class="form-control" placeholder="Add gst" name="gst" value="{{ old('gst') }}">
                     </div>
                      <div class="form-group col-md-6">
                        <label>Buy/Sale/Both<span style="color:red"> *</span></label>
                        <select name="buy_sale_both" id="product" class="form-control">
                            <option disabled="" selected="" hidden>Select</option>
                            <option>Buy</option>
                            <option>Sale</option> 
                            <option>Both</option>    
                        </select>
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Category<span style="color:red"> *</span></label>
                        <select name="category_id" id="category" class="form-control">
                            <option disabled="" selected="" hidden>Select Category</option>
                            @foreach ($category as $categorys)
                                <option value="{{ $categorys->id }}" {{ old('category_id') == $categorys->id ? 'selected' : '' }}>{{ $categorys->name }}</option>
                            @endforeach
                          
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Brand</label>
                          <select name="brand_id" id="brand" class="form-control">
                            <option disabled="" selected="" hidden>Select Brand</option>
                            @foreach ($brand as $brands)
                                <option value="{{ $brands->name }}" {{ old('brand_id') == $brands->name ? 'selected' : '' }}>{{ $brands->name }}</option>
                            @endforeach
                          
                        </select>
                     </div>
                     </div>


                <div class="row">  
                 <div class="form-group col-md-6">
                        <label>Vendor Name</label>
                          <select name="vendor_name" id="vendor_name" class="form-control">
                            <option disabled="" selected="" hidden>Select Vendor Name</option>
                            @foreach ($vendor  as $vendors)
                            <option value="{{ $vendors->company }}" {{ old('vendor_name') == $vendors->company ? 'selected' : '' }}>{{ $vendors->company }}</option>
                            @endforeach  
                        </select>
                     </div>  
                     <div class="form-group col-md-6">
                        <label>Vendor Location</label>
                        <input type="text" class="form-control" placeholder="Add vendor location" name="vendor_location" value="{{ old('vender_location') }}">
                     </div>
                </div>

                <div class="row">
                <div class="form-group col-md-6">
                        <label>Product/Service</label>
                        <select name="product_service_name" id="product" class="form-control">
                            <option disabled="" selected="" hidden>Select</option>
                            <option>Product</option>
                            <option>Service</option>    
                        </select>
                    </div>    
                    <div class="form-group col-md-6">
                        <label>Current Stock</label>
                        <input type="text" class="form-control" placeholder="Add stock" name="current_stock" >
                     </div>
                </div>

                <div class="row"> 
                  <div class="form-group col-md-6">
                        <label>Min Stock Level</label>
                        <input type="number" class="form-control" placeholder="Add min stock" name="min_stock_level" value="{{ old('min_stock_level') }}">
                     </div>    
                    <div class="form-group col-md-6">
                        <label>Max Stock Level</label>
                        <input type="number" class="form-control" placeholder="Add max stock" name="max_stock_level" value="{{ old('max_stock_level') }} " >
                     </div>
                </div>

                <div class="row">  
                 <div class="form-group col-md-6">
                        <label>Select Department<span style="color:red"> *</span></label>
                        <select name="department" id="dapart" class="form-control">
                            <option disabled="" selected="" hidden>Select Department</option>
                            @foreach ($department  as $departments)
                                <option value="{{ $departments->name }}" {{ old('department') == $departments->name ? 'selected' : '' }}>{{ $departments->name }}</option>
                            @endforeach  
                        </select>
                    </div>  
                   <div class="form-group col-md-6">
                        <label>Location<span style="color:red"> *</span></label>
                         <select name="location" id="location" class="form-control">
                            <option disabled="" selected="" hidden>Select Site Name</option>
                            @foreach ($sites as $ste)
                                <option value="{{ $ste->name }}" {{ old('location') == $ste->name ? 'selected' : '' }}>{{ $ste->name }}</option>
                            @endforeach  
                        </select>
                     </div>
                    </div>
                    
                    <div class="row">  
                    <div class="form-group col-md-6">
                        <label>Consumption</label>
                        <select name="consumption" class="form-control">
                            <option disabled="" selected="" hidden>Select level</option>
                            <option>level(1 year)</option>
                            <option>level(2 year)</option>
                            <option>level(3 year)</option> 
                        </select>
                    </div>   
                    <div class="form-group col-md-6">
                        <label>Consumable</label>
                        <input type="text" class="form-control" placeholder="" name="consumable" value="{{ old('consumerable') }} ">
                     </div>
                    </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            </div> 
          </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
    $('#OpenImgUpload').click(function(){ $('#imgupload').trigger('click'); });
</script>
@endsection

{{-- {{ route('excel_import') }} --}}