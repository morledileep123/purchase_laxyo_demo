@extends('../layouts.master')
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" rel="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

@section('content')

<!-- Show remove reason RFI -->
<div class="modal fade" id="decline_request_show" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <p class="modal-title" id="exampleModalCenterTitle">Decline Request</p>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <textarea id="remove_reason" class="form-control" rows="6%" readonly></textarea>          
        </div>
      </div>
  </div>
</div>

<div class="container-fluid">
  	<div class="card">
  <!-- Content Header (Page header) -->

    <div class="card-header">
      <div class="row">
        <div class="col-md-12">
          <div class="float-right">
            <a href="{{ '/home' }}" class="btn btn-secondary btn-sm">Back</a>
          </div>
          <h5>RFI's details</h5>
        </div>
      </div>
    </div>
    <div class="card-body">
        @if ($errors->any())
            <div class="alert alert-danger">
                <strong>Warning!</strong> Please check your input code<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
					
        <h5><strong>{{ "Site - ".App\SiteName::find($requestForItem[0]->site_id)->name }}</strong></h5>
        <h5><strong>Expected Date - {{ date('d-m-Y', strtotime($requestForItem[0]->expected_date)) }}</strong></h5>
        <table id="invoice-item-table" class="table table-bordered">
            <tr>
              <th>S.No</th>
              <th>Item Name</th>
              <th>Item No.</th>		      
              <th>Quantity</th>
              <th>Sending qty</th>		             
              <th>Remark</th>
              <th>Status</th>
            </tr>
            @php $m = 1; @endphp
            @foreach($requestForItem as $row)
            <tr>
              	<td><span id="sr_no">{{$m++}}</span></td>
              	<td>{{ $row->item_name }}</td>
              	<td>{{ $row->item_no }}</td>
              	<td>{{ $row->quantity }}  {{ $row->quantity_unit }}</td>
                <td>{{ $row->fquantity }}</td>		  
               	<td>{{ $row->description }}</td>

	            @if($row->remove_reason != null)
	              <td><button type="button" class="btn btn-danger show_remove_request btn-sm" value="{{$row->remove_reason}}">Reason</button></td>
	            @elseif($row->remove_item_status == 2)
	              <td class="text-danger">Declined</td>
	            @elseif($row->remove_item_status == 3)
	              <button type="button" class="btn btn-danger remove_request" value="{{$row->id}}">Declined</button>
	            @else
	              <td class="text-success">Accepted</td>
	            @endif
            </tr>
           	@endforeach
        </table>   
    </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript">
 $(document).ready(function(){
    // show remove rfi reason 
    $('.show_remove_request').click(function(e){
      e.preventDefault();
      var remove_reason = $(this).val();
      
      $('#remove_reason').val(remove_reason);

      $('#decline_request_show').modal('show');

    });

});
</script>
@endsection