<!DOCTYPE html>
<html>
<head>
    <title>Received Items</title>
</head>
<body>
 <div>
  <h6>Hi {{ $uname }} ! <h6></br>
    <p>Vendor Have Send Requested Items  on {{date('Y-m-d')}}</p></br>
    <p>Kindly Store In W-house</p></br>
    <p>Please go through this link : <a href="http://www.laxyo.org" >Here</a>

 </div>
</body>
</html>
