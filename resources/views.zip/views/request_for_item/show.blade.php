@extends('../layouts.master')

@section('content')
<div class="container-fluid">
	<div class="card shadow mb-4">
    <div class="card-header">
      <div class="row">
        <div class="col-sm-6">
          <h5>View RFI details</h5>
        </div>
        <div class="col-sm-6">
            <div class="float-sm-right">
              <a href="{{ url('request_for_item') }}" class="btn btn-secondary btn-sm">Back</a>
            </div>
        </div>
      </div>
    </div>

    <div class="card-body">		
        <h5><strong>{{ "Site - ".App\SiteName::find($item[0]->site_name)->name }}</strong></h5>
        <h5><strong>Expected Date - {{ date('d-m-Y', strtotime($item[0]->expected_date)) }}</strong></h5>
        <table id="invoice-item-table" class="table table-bordered">
            <tr>
              <th>S.No</th>
              <th>Item Name</th>
              <th>Item No.</th>
              <th>Quantity</th>
              <th>Sending qty</th>
              <th>Remark</th>
              <th>Status</th>
            </tr>
            @php $m = 1; @endphp
            @foreach($item as $row)
            <tr>
              <td>{{ $m++ }}</td>
              <td>{{ $row->item_name }}</td>
              <td>{{ $row->item_no }}</td>
              <td>{{ $row->quantity }}  {{ $row->quantity_unit }}</td>
              <td>{{ $row->a_quantity }}</td>
              <td>{{ $row->description }}</td>

              @if($row->despatch_status == 1)
              <td class="text-secondary">Decline</td>

              @elseif($row->admin_approve == 1 && $row->admin_status == 1 && $row->manager_approve  == 1 && $row->manager_status == 1 )
                <td class="text-success">Admin Approve</td>

              @elseif($row->admin_status == 1 && $row->manager_approve  == 1 && $row->manager_status == 1 )
                <td class="text-primary">Manager Approve</td>

              @else
              <td class="text-primary">Processing</td>
              @endif
            </tr>
           @endforeach
        </table>
    </div>
    </div>
</div>
@endsection